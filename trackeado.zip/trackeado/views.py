# views.py
from django.conf import settings
from django.shortcuts import render
from django.http import JsonResponse
from django.views.decorators.http import require_GET
import yfinance as yf

def stock_dashboard(request):
    context = {
        'finnhub_api_key': settings.FINNHUB_API_KEY,
    }
    return render(request, 'dashboard.html', context)


@require_GET
def stock_quote(request, symbol):
    """
    Devuelve el precio actual de un símbolo vía yfinance, incluyendo
    precio de pre-market / after-hours cuando el mercado regular está cerrado.

    yfinance no es una API oficial de Yahoo Finance (hace scraping), así que
    puede fallar o cambiar de formato sin aviso. No usar como fuente única
    para nada crítico.
    """
    symbol = symbol.strip().upper()
    if not symbol.isalnum() or len(symbol) > 10:
        return JsonResponse({'error': 'Símbolo inválido.'}, status=400)

    try:
        ticker = yf.Ticker(symbol)
        info = ticker.info or {}
    except Exception as exc:
        return JsonResponse(
            {'error': f'No se pudo obtener datos de {symbol}: {exc}'},
            status=502,
        )

    market_state = info.get('marketState', 'UNKNOWN')
    # marketState típicamente es: PRE, REGULAR, POST, CLOSED, POSTPOST, PREPRE

    data = {
        'symbol': symbol,
        'marketState': market_state,
        'regularMarketPrice': info.get('regularMarketPrice'),
        'preMarketPrice': info.get('preMarketPrice'),
        'preMarketChangePercent': info.get('preMarketChangePercent'),
        'postMarketPrice': info.get('postMarketPrice'),
        'postMarketChangePercent': info.get('postMarketChangePercent'),
    }
    return JsonResponse(data)